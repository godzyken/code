
vesion du java web app
-javaee/web-app_3_0.xsd

version du jre
-1.8

version du server
-tomcat9