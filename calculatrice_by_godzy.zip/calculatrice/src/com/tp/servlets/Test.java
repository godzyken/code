package com.tp.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tp.calculatrice.Operation;


/**

 * Servlet implementation class Test

 */

public class Test extends HttpServlet {

    private static final long serialVersionUID = 1L;

//-------------------------------------------Constructeur par defaut--------------------------------------------------------//
    
    public Test() {

        super();

    }
    
//--------------------------------------------Methodes------------------------------------------------------------------------//

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        this.getServletContext().getRequestDispatcher("/WEB-INF/calculatrice.jsp").forward(request, response);

    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	int operande1 = Integer.parseInt(request.getParameter("operande1"));
    	int operande2= Integer.parseInt(request.getParameter("operande2"));
    	
    	System.out.println("operande1 : " + operande1);
    	System.out.println("operande2 : " + operande2);
    	
        Operation operation= new Operation(Integer.parseInt(request.getParameter("operande1")), request.getParameter("operateur"), Integer.parseInt(request.getParameter("operande2")));

        System.out.println("operation : " + operation);
        
        request.setAttribute("operation", operation);
        
        this.getServletContext().getRequestDispatcher("/WEB-INF/calculatrice.jsp").forward(request, response);

    }


}